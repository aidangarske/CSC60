/* utils.h
 * Aidan Garske
 * CSC 60 fall 2025
 * 9/27/25
*/

int getRange(int firstNum, int lastNum);
void printHeader();
void printColumnHeaders();
void printDataLine(int fNum, int lNum, int range);
