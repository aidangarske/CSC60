/* lab5.h
 * Aidan Garske
 * CSC 60 fall 2025
 * 9/27/25
*/

#define TITLE "\n\nRange Counter Report\n"
