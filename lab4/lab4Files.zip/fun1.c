/* fun1.c
 * 
 * Lab 4
 * Aidan Garske
 * 9/21/2025
 */

/* Contains the square function */
int fun1(int num) {
    return num * num;
}
