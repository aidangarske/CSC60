/* fun2_3.c
 * 
 * Lab 4
 * Aidan Garske
 * 9/21/2025
 */

/* Contains the next integer and half functions */
int fun2(int num) {
    return num + 1;
}

float fun3(int num) {
    return (float)num / 2.0;
}
